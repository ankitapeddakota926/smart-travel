import { useState, useEffect } from 'react';
import type { User } from '../types';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate checking for existing authentication
    const savedUser = localStorage.getItem('tourist-user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Failed to parse saved user:', error);
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Determine role based on email for demo purposes
    let role: User['role'] = 'tourist';
    if (email.includes('police') || email.includes('authority')) role = 'police';
    else if (email.includes('family')) role = 'family';
    else if (email.includes('admin')) role = 'admin';
    else if (email.includes('tourism')) role = 'tourism';
    
    const mockUser: User = {
      id: '1',
      name: 'John Tourist',
      email,
      role,
      digitalId: 'DID-2024-001',
      safetyScore: 85,
      emergencyContacts: [
        { id: '1', name: 'Emergency Contact', phone: '+1-555-0123', relationship: 'Family' }
      ],
      permissions: role === 'admin' ? ['all'] : role === 'police' ? ['emergency', 'alerts'] : ['basic']
    };

    setUser(mockUser);
    localStorage.setItem('tourist-user', JSON.stringify(mockUser));
    return mockUser;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('tourist-user');
  };

  return { user, isLoading, login, logout };
};