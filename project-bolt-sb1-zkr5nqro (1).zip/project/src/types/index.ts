export interface User {
  id: string;
  name: string;
  email: string;
  role: 'tourist' | 'family' | 'police' | 'tourism' | 'admin';
  digitalId?: string;
  emergencyContacts?: EmergencyContact[];
  safetyScore?: number;
  permissions?: string[];
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relationship: string;
}

export interface Location {
  lat: number;
  lng: number;
  address?: string;
}

export interface SafetyAlert {
  id: string;
  type: 'danger' | 'warning' | 'info';
  message: string;
  location?: Location;
  timestamp: Date;
}

export interface TravelRecommendation {
  id: string;
  type: 'attraction' | 'restaurant' | 'hotel' | 'event';
  name: string;
  description: string;
  rating: number;
  image: string;
  location: Location;
}