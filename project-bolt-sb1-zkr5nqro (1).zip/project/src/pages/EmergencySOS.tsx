import React, { useState } from 'react';
import { AlertTriangle, Phone, MapPin, Clock, User, Shield, Zap } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export const EmergencySOS: React.FC = () => {
  const { user } = useAuth();
  const [sosActive, setSosActive] = useState(false);

  const emergencyServices = [
    { name: 'Police', number: '911', icon: Shield, color: 'blue' },
    { name: 'Medical Emergency', number: '911', icon: Phone, color: 'red' },
    { name: 'Fire Department', number: '911', icon: AlertTriangle, color: 'orange' },
    { name: 'Tourist Helpline', number: '1-800-TOURIST', icon: User, color: 'green' }
  ];

  const handleSOSActivation = () => {
    setSosActive(true);
    // Simulate SOS activation
    setTimeout(() => {
      alert('🚨 SOS ACTIVATED!\n\n✅ Location shared with authorities\n✅ Emergency contacts notified\n✅ Local police dispatched\n✅ Medical assistance alerted\n\nStay calm. Help is on the way!');
      setSosActive(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      {/* Emergency SOS Button */}
      <div className="bg-gradient-to-br from-red-500 to-red-600 text-white p-8 rounded-2xl shadow-xl">
        <div className="text-center">
          <AlertTriangle className="w-16 h-16 mx-auto mb-4" />
          <h1 className="text-3xl font-bold mb-2">Emergency SOS</h1>
          <p className="text-red-100 mb-6">Press and hold for immediate emergency assistance</p>
          
          <button
            onClick={handleSOSActivation}
            disabled={sosActive}
            className={`w-32 h-32 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl transition-all duration-200 ${
              sosActive 
                ? 'bg-red-800 animate-pulse cursor-not-allowed' 
                : 'bg-red-700 hover:bg-red-800 hover:scale-105 active:scale-95'
            }`}
          >
            {sosActive ? (
              <div className="text-center">
                <Zap className="w-12 h-12 mb-1 animate-bounce" />
                <div>ACTIVE</div>
              </div>
            ) : (
              <div className="text-center">
                <AlertTriangle className="w-12 h-12 mb-1" />
                <div>SOS</div>
              </div>
            )}
          </button>
          
          <p className="text-sm text-red-100">
            This will immediately alert local authorities and your emergency contacts
          </p>
        </div>
      </div>

      {/* Emergency Contacts */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Emergency Services</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {emergencyServices.map((service, index) => {
            const Icon = service.icon;
            const colorClasses = {
              blue: 'bg-blue-50 border-blue-200 hover:bg-blue-100',
              red: 'bg-red-50 border-red-200 hover:bg-red-100',
              orange: 'bg-orange-50 border-orange-200 hover:bg-orange-100',
              green: 'bg-green-50 border-green-200 hover:bg-green-100'
            };

            return (
              <button
                key={index}
                className={`p-4 rounded-xl border-2 transition-colors text-left ${
                  colorClasses[service.color as keyof typeof colorClasses]
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`w-8 h-8 ${
                    service.color === 'blue' ? 'text-blue-600' :
                    service.color === 'red' ? 'text-red-600' :
                    service.color === 'orange' ? 'text-orange-600' :
                    'text-green-600'
                  }`} />
                  <div>
                    <h3 className="font-semibold">{service.name}</h3>
                    <p className="text-sm text-gray-600">{service.number}</p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Personal Emergency Contacts */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Your Emergency Contacts</h2>
        
        <div className="space-y-3">
          {user?.emergencyContacts?.map((contact) => (
            <div key={contact.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium">{contact.name}</h3>
                  <p className="text-sm text-gray-600">{contact.relationship}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-700">{contact.phone}</span>
                <button className="bg-green-600 text-white p-2 rounded-lg hover:bg-green-700 transition-colors">
                  <Phone className="w-4 h-4" />
                </button>
              </div>
            </div>
          )) || (
            <div className="p-4 bg-gray-50 rounded-lg text-center">
              <p className="text-gray-600">No emergency contacts configured</p>
              <button className="mt-2 text-blue-600 hover:text-blue-700 font-medium">
                Add Emergency Contact
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Current Location & Status */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Current Status</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium mb-3 flex items-center">
              <MapPin className="w-4 h-4 mr-1 text-red-500" />
              Live Location
            </h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-gray-700 mb-2">Times Square, New York</p>
              <p className="text-sm text-gray-600">Coordinates: 40.7580° N, 73.9855° W</p>
              <p className="text-sm text-gray-600">Last updated: Just now</p>
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-3 flex items-center">
              <Clock className="w-4 h-4 mr-1 text-blue-500" />
              Safety Status
            </h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Zone Safety</span>
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">SAFE</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Connection</span>
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">STRONG</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Nearest Safe Zone</span>
                <span className="text-xs text-gray-600">Police Station (0.2 mi)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Quick Emergency Actions</h2>
        
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="p-4 bg-blue-50 rounded-lg text-center hover:bg-blue-100 transition-colors">
            <MapPin className="w-6 h-6 text-blue-600 mx-auto mb-2" />
            <span className="text-sm font-medium">Share Location</span>
          </button>
          
          <button className="p-4 bg-green-50 rounded-lg text-center hover:bg-green-100 transition-colors">
            <Phone className="w-6 h-6 text-green-600 mx-auto mb-2" />
            <span className="text-sm font-medium">Call Contact</span>
          </button>
          
          <button className="p-4 bg-purple-50 rounded-lg text-center hover:bg-purple-100 transition-colors">
            <AlertTriangle className="w-6 h-6 text-purple-600 mx-auto mb-2" />
            <span className="text-sm font-medium">Send Alert</span>
          </button>
          
          <button className="p-4 bg-orange-50 rounded-lg text-center hover:bg-orange-100 transition-colors">
            <Shield className="w-6 h-6 text-orange-600 mx-auto mb-2" />
            <span className="text-sm font-medium">Safe Route</span>
          </button>
        </div>
      </div>

      {/* Important Information */}
      <div className="bg-yellow-50 border border-yellow-200 p-6 rounded-xl">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-6 h-6 text-yellow-600 mt-1" />
          <div>
            <h3 className="font-semibold text-yellow-800 mb-2">Important Emergency Information</h3>
            <ul className="text-sm text-yellow-700 space-y-1">
              <li>• SOS activation immediately shares your location with authorities</li>
              <li>• Emergency contacts will receive automatic notifications</li>
              <li>• Local emergency services will be dispatched to your location</li>
              <li>• Keep your phone charged and location services enabled</li>
              <li>• If possible, move to a well-lit, public area</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};