import React from 'react';
import { Star, MessageCircle, User } from 'lucide-react';

export const Reviews: React.FC = () => {
  const reviews = [
    {
      id: '1',
      user: 'Sarah Johnson',
      rating: 5,
      comment: 'Amazing safety features! The panic button gave me peace of mind during my solo trip.',
      location: 'Central Park',
      date: '2 days ago'
    },
    {
      id: '2',
      user: 'Mike Chen',
      rating: 4,
      comment: 'Great recommendations for restaurants. The AI assistant was very helpful.',
      location: 'Downtown District',
      date: '1 week ago'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h1 className="text-2xl font-bold mb-2">Reviews & Community</h1>
        <p className="text-gray-600">Share your experiences and read what other tourists say</p>
      </div>

      <div className="space-y-4">
        {reviews.map((review) => (
          <div key={review.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="font-semibold">{review.user}</span>
                  <div className="flex">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-500 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 mb-2">{review.comment}</p>
                <div className="text-sm text-gray-500">
                  {review.location} • {review.date}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Share Your Experience</h2>
        <div className="space-y-4">
          <div className="flex space-x-2">
            {[1, 2, 3, 4, 5].map((rating) => (
              <Star key={rating} className="w-6 h-6 text-gray-300 hover:text-yellow-500 cursor-pointer" />
            ))}
          </div>
          <textarea
            placeholder="Share your experience with other tourists..."
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows={4}
          />
          <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
            Post Review
          </button>
        </div>
      </div>
    </div>
  );
};