import React, { useState } from 'react';
import { MessageCircle, Send, Bot, User, HelpCircle, Phone, Mail } from 'lucide-react';

export const Support: React.FC = () => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([
    {
      id: '1',
      sender: 'ai',
      text: 'Hello! I\'m your AI Travel Assistant. I can help you with travel planning, safety information, emergency assistance, and answer questions in multiple languages. How can I help you today?',
      timestamp: new Date()
    }
  ]);

  const quickQuestions = [
    'Find nearby restaurants',
    'Safety tips for my location',
    'Best tourist attractions',
    'Weather forecast',
    'Emergency services',
    'Currency exchange rates'
  ];

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage = {
        id: Date.now().toString(),
        sender: 'user' as const,
        text: message,
        timestamp: new Date()
      };
      
      setMessages([...messages, newMessage]);
      setMessage('');

      // Simulate AI response
      setTimeout(() => {
        const aiResponse = {
          id: (Date.now() + 1).toString(),
          sender: 'ai' as const,
          text: 'Thank you for your message! I\'m processing your request and will provide you with the most relevant and safe information. Is there anything specific about your current location or travel plans I should know about?',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiResponse]);
      }, 1000);
    }
  };

  const handleQuickQuestion = (question: string) => {
    setMessage(question);
  };

  return (
    <div className="space-y-6">
      {/* AI Chat Interface */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 h-96 flex flex-col">
        <div className="p-4 border-b border-gray-100 flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
            <Bot className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h2 className="font-semibold">AI Travel Assistant</h2>
            <p className="text-sm text-gray-500">Multilingual • 24/7 Available</p>
          </div>
        </div>

        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                <div className="flex items-start space-x-2">
                  {msg.sender === 'ai' && (
                    <Bot className="w-4 h-4 mt-1 text-blue-600" />
                  )}
                  {msg.sender === 'user' && (
                    <User className="w-4 h-4 mt-1 text-white" />
                  )}
                  <div>
                    <p className="text-sm">{msg.text}</p>
                    <p className={`text-xs mt-1 ${
                      msg.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      {msg.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-gray-100">
          <div className="flex space-x-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask me anything about your travel..."
              className="flex-1 p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button
              onClick={handleSendMessage}
              className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Quick Questions */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="font-semibold mb-4">Quick Questions</h3>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
          {quickQuestions.map((question, index) => (
            <button
              key={index}
              onClick={() => handleQuickQuestion(question)}
              className="p-3 text-left text-sm bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
            >
              {question}
            </button>
          ))}
        </div>
      </div>

      {/* Contact Support */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Contact Human Support</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3 mb-3">
              <Phone className="w-5 h-5 text-green-600" />
              <h3 className="font-medium">Emergency Hotline</h3>
            </div>
            <p className="text-gray-600 text-sm mb-2">24/7 immediate assistance</p>
            <p className="font-semibold">+1-800-SAFETOUR</p>
          </div>
          
          <div className="p-4 border border-gray-200 rounded-lg">
            <div className="flex items-center space-x-3 mb-3">
              <Mail className="w-5 h-5 text-blue-600" />
              <h3 className="font-medium">Email Support</h3>
            </div>
            <p className="text-gray-600 text-sm mb-2">Response within 2 hours</p>
            <p className="font-semibold">support@safetour.com</p>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <HelpCircle className="w-5 h-5 mr-2" />
          Frequently Asked Questions
        </h2>
        
        <div className="space-y-4">
          {[
            {
              q: 'How does the panic button work?',
              a: 'The panic button immediately shares your location with local authorities, emergency contacts, and tourist safety services.'
            },
            {
              q: 'Is my data secure with blockchain?',
              a: 'Yes, all personal information is encrypted and stored on a secure blockchain network that you control.'
            },
            {
              q: 'Can the AI assistant help in different languages?',
              a: 'Absolutely! Our AI supports over 50 languages and can provide real-time translation services.'
            }
          ].map((faq, index) => (
            <div key={index} className="border-l-4 border-blue-500 pl-4">
              <h4 className="font-medium text-gray-900 mb-1">{faq.q}</h4>
              <p className="text-gray-600 text-sm">{faq.a}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};