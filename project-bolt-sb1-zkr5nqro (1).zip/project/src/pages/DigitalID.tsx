import React, { useState } from 'react';
import { CreditCard, User, Phone, Mail, Shield, Edit, Download } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export const DigitalID: React.FC = () => {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);

  return (
    <div className="space-y-6">
      {/* Digital ID Card */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white p-8 rounded-2xl shadow-xl">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold mb-2">Digital Tourist ID</h1>
            <p className="text-blue-100">Blockchain-Secured Identity</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-200">ID Number</p>
            <p className="font-mono text-lg">{user?.digitalId || 'DID-2024-001'}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center">
                <User className="w-8 h-8" />
              </div>
              <div>
                <h2 className="text-xl font-semibold">{user?.name || 'John Tourist'}</h2>
                <p className="text-blue-200">Tourist</p>
              </div>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex items-center">
                <Mail className="w-4 h-4 mr-2" />
                {user?.email || 'john.tourist@email.com'}
              </div>
              <div className="flex items-center">
                <Shield className="w-4 h-4 mr-2" />
                Safety Score: {user?.safetyScore || 85}/100
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Verification Status</h3>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Identity Verified</span>
                  <span className="text-green-300">✓</span>
                </div>
                <div className="flex justify-between">
                  <span>Blockchain Registered</span>
                  <span className="text-green-300">✓</span>
                </div>
                <div className="flex justify-between">
                  <span>Emergency Contacts</span>
                  <span className="text-green-300">✓</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-blue-500 flex justify-between items-center">
          <p className="text-xs text-blue-200">
            Valid until: December 2024 • Issued by: Tourist Safety Authority
          </p>
          <button className="bg-blue-500 hover:bg-blue-400 px-4 py-2 rounded-lg transition-colors text-sm font-medium">
            <Download className="w-4 h-4 inline mr-1" />
            Export QR
          </button>
        </div>
      </div>

      {/* Personal Information */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">Personal Information</h2>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center"
          >
            <Edit className="w-4 h-4 mr-1" />
            {isEditing ? 'Save' : 'Edit'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              {isEditing ? (
                <input
                  type="text"
                  defaultValue={user?.name || 'John Tourist'}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              ) : (
                <p className="text-gray-900">{user?.name || 'John Tourist'}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              {isEditing ? (
                <input
                  type="email"
                  defaultValue={user?.email || 'john.tourist@email.com'}
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              ) : (
                <p className="text-gray-900">{user?.email || 'john.tourist@email.com'}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
              {isEditing ? (
                <input
                  type="tel"
                  defaultValue="+1 (555) 123-4567"
                  className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              ) : (
                <p className="text-gray-900">+1 (555) 123-4567</p>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nationality</label>
              {isEditing ? (
                <select className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option>United States</option>
                  <option>Canada</option>
                  <option>United Kingdom</option>
                  <option>Other</option>
                </select>
              ) : (
                <p className="text-gray-900">United States</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Current Location</label>
              <p className="text-gray-900">New York, NY</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Travel Dates</label>
              {isEditing ? (
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    className="p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <input
                    type="date"
                    className="p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              ) : (
                <p className="text-gray-900">Jan 15 - Jan 25, 2024</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Contacts */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-6">Emergency Contacts</h2>
        
        <div className="space-y-4">
          {user?.emergencyContacts?.map((contact, index) => (
            <div key={contact.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <h3 className="font-medium">{contact.name}</h3>
                <p className="text-sm text-gray-600">{contact.relationship}</p>
                <p className="text-sm text-gray-600">{contact.phone}</p>
              </div>
              <button className="text-blue-600 hover:text-blue-700">
                <Edit className="w-4 h-4" />
              </button>
            </div>
          )) || (
            <div className="p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium">Primary Emergency Contact</h3>
              <p className="text-sm text-gray-600">Family Member</p>
              <p className="text-sm text-gray-600">+1 (555) 987-6543</p>
            </div>
          )}
          
          <button className="w-full py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-600 hover:border-blue-300 hover:text-blue-600 transition-colors">
            + Add Emergency Contact
          </button>
        </div>
      </div>

      {/* Blockchain Security */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <Shield className="w-5 h-5 mr-2 text-green-600" />
          Blockchain Security
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <Shield className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-medium">Encrypted</h3>
            <p className="text-sm text-gray-600">End-to-end encryption</p>
          </div>
          
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <CreditCard className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="font-medium">Verified</h3>
            <p className="text-sm text-gray-600">Identity confirmed</p>
          </div>
          
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <User className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-medium">Decentralized</h3>
            <p className="text-sm text-gray-600">Your data, your control</p>
          </div>
        </div>
      </div>
    </div>
  );
};