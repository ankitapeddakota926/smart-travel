import React, { useState } from 'react';
import { Map, Star, MapPin, Filter, Search, Navigation } from 'lucide-react';
import { MOCK_RECOMMENDATIONS } from '../utils/constants';

export const TravelGuide: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filters = [
    { id: 'all', label: 'All', count: 24 },
    { id: 'attraction', label: 'Attractions', count: 8 },
    { id: 'restaurant', label: 'Restaurants', count: 12 },
    { id: 'hotel', label: 'Hotels', count: 6 },
    { id: 'event', label: 'Events', count: 4 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h1 className="text-2xl font-bold mb-2">Travel Guide & Recommendations</h1>
        <p className="text-gray-600">AI-powered personalized suggestions for your perfect trip</p>
      </div>

      {/* Interactive Map */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold flex items-center">
            <Map className="w-5 h-5 mr-2 text-blue-600" />
            Interactive Map & Safe Zones
          </h2>
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center">
            <Navigation className="w-4 h-4 mr-1" />
            Get Directions
          </button>
        </div>
        
        <div className="bg-gray-100 rounded-xl h-80 flex items-center justify-center mb-4">
          <div className="text-center">
            <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-2">Interactive map with real-time data</p>
            <p className="text-sm text-gray-500">
              Showing tourist attractions, safe zones, restaurants, and current location
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 text-sm">
          <div className="flex items-center">
            <div className="w-4 h-4 bg-green-500 rounded-full mr-2"></div>
            <span>Safe Zones (12 nearby)</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-blue-500 rounded-full mr-2"></div>
            <span>Tourist Attractions</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-orange-500 rounded-full mr-2"></div>
            <span>Restaurants & Cafes</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-purple-500 rounded-full mr-2"></div>
            <span>Hotels & Lodging</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-red-500 rounded-full mr-2"></div>
            <span>Restricted Areas</span>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search attractions, restaurants, events..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-gray-400" />
            <div className="flex flex-wrap gap-2">
              {filters.map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    activeFilter === filter.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {filter.label} ({filter.count})
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Recommendations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_RECOMMENDATIONS.map((item) => (
          <div key={item.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
            <div className="aspect-w-16 aspect-h-9">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-48 object-cover"
              />
            </div>
            
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-semibold text-lg">{item.name}</h3>
                <div className="flex items-center text-sm">
                  <Star className="w-4 h-4 text-yellow-500 mr-1" />
                  <span className="font-medium">{item.rating}</span>
                </div>
              </div>
              
              <p className="text-gray-600 mb-4 text-sm">{item.description}</p>
              
              <div className="flex items-center justify-between">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  item.type === 'attraction' ? 'bg-blue-100 text-blue-800' :
                  item.type === 'restaurant' ? 'bg-orange-100 text-orange-800' :
                  item.type === 'hotel' ? 'bg-purple-100 text-purple-800' :
                  'bg-green-100 text-green-800'
                }`}>
                  {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                </span>
                
                <div className="flex space-x-2">
                  <button className="text-blue-600 hover:text-blue-700 p-1">
                    <MapPin className="w-4 h-4" />
                  </button>
                  <button className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 transition-colors text-xs">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* AI Recommendations */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">AI-Powered Suggestions</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-xl">
            <h3 className="font-semibold text-blue-800 mb-2">Hidden Gems Near You</h3>
            <p className="text-blue-700 text-sm mb-4">
              Based on your preferences and current location, here are some lesser-known attractions worth visiting.
            </p>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
              Discover Hidden Gems
            </button>
          </div>
          
          <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-xl">
            <h3 className="font-semibold text-green-800 mb-2">Safety-First Routes</h3>
            <p className="text-green-700 text-sm mb-4">
              Optimized routes that prioritize your safety while ensuring you don't miss the best experiences.
            </p>
            <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm">
              Plan Safe Route
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};