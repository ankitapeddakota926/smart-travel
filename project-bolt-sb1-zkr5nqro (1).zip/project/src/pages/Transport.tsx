import React from 'react';
import { Car, MapPin, Clock, DollarSign, Navigation } from 'lucide-react';

export const Transport: React.FC = () => {
  const transportOptions = [
    { type: 'Taxi', eta: '3 min', price: '$8-12', available: 4, color: 'yellow' },
    { type: 'Bus', eta: '7 min', price: '$2.50', available: 2, color: 'blue' },
    { type: 'Metro', eta: '5 min', price: '$3.00', available: 1, color: 'green' },
    { type: 'Rideshare', eta: '4 min', price: '$6-9', available: 8, color: 'purple' }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h1 className="text-2xl font-bold mb-2">Transport & Navigation</h1>
        <p className="text-gray-600">Find safe and convenient transportation options</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {transportOptions.map((option, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <Car className={`w-8 h-8 ${
                option.color === 'yellow' ? 'text-yellow-500' :
                option.color === 'blue' ? 'text-blue-500' :
                option.color === 'green' ? 'text-green-500' :
                'text-purple-500'
              }`} />
              <span className="bg-gray-100 px-2 py-1 rounded text-sm">{option.available} available</span>
            </div>
            
            <h3 className="font-semibold text-lg mb-2">{option.type}</h3>
            
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-2" />
                {option.eta}
              </div>
              <div className="flex items-center">
                <DollarSign className="w-4 h-4 mr-2" />
                {option.price}
              </div>
            </div>
            
            <button className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
              Book Now
            </button>
          </div>
        ))}
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Safe Route Navigation</h2>
        <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
          <div className="text-center">
            <Navigation className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Route navigation will appear here</p>
          </div>
        </div>
      </div>
    </div>
  );
};