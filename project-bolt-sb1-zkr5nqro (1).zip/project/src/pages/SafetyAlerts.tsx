import React, { useState } from 'react';
import { AlertTriangle, Shield, MapPin, Clock, Bell, TrendingUp } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export const SafetyAlerts: React.FC = () => {
  const { user } = useAuth();
  const [alertsEnabled, setAlertsEnabled] = useState(true);

  const alerts = [
    {
      id: '1',
      type: 'warning' as const,
      title: 'Heavy Traffic Alert',
      message: 'Avoid Main Street due to ongoing construction. Alternative routes suggested.',
      location: 'Main Street, Downtown',
      time: '2 hours ago',
      severity: 'medium'
    },
    {
      id: '2',
      type: 'info' as const,
      title: 'Cultural Festival',
      message: 'Street festival happening at Central Park. Expect crowds and road closures.',
      location: 'Central Park Area',
      time: '4 hours ago',
      severity: 'low'
    },
    {
      id: '3',
      type: 'danger' as const,
      title: 'Weather Advisory',
      message: 'Severe thunderstorm warning. Seek indoor shelter immediately.',
      location: 'City-wide',
      time: '6 hours ago',
      severity: 'high'
    }
  ];

  const safetyMetrics = [
    { label: 'Your Safety Score', value: user?.safetyScore || 85, change: '+5', color: 'green' },
    { label: 'Safe Zone Distance', value: '0.3 mi', change: 'Optimal', color: 'green' },
    { label: 'Active Alerts', value: 3, change: '-2', color: 'blue' },
    { label: 'Risk Level', value: 'Low', change: 'Stable', color: 'green' }
  ];

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'danger': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      default: return <Bell className="w-5 h-5 text-blue-500" />;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'danger': return 'border-red-200 bg-red-50';
      case 'warning': return 'border-yellow-200 bg-yellow-50';
      default: return 'border-blue-200 bg-blue-50';
    }
  };

  return (
    <div className="space-y-6">
      {/* Safety Score Dashboard */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold flex items-center">
            <Shield className="w-6 h-6 mr-2 text-green-600" />
            Safety & Alert Center
          </h1>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">Push Notifications</span>
            <button
              onClick={() => setAlertsEnabled(!alertsEnabled)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                alertsEnabled ? 'bg-green-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  alertsEnabled ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {safetyMetrics.map((metric, index) => (
            <div key={index} className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">{metric.label}</span>
                <TrendingUp className="w-4 h-4 text-gray-400" />
              </div>
              <div className="flex items-end justify-between">
                <span className="text-2xl font-bold text-gray-900">{metric.value}</span>
                <span className={`text-xs px-2 py-1 rounded ${
                  metric.color === 'green' ? 'bg-green-100 text-green-800' :
                  metric.color === 'blue' ? 'bg-blue-100 text-blue-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {metric.change}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Current Alerts */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Current Alerts</h2>
        
        <div className="space-y-4">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-4 rounded-lg border-l-4 ${getAlertColor(alert.type)}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <div className="mt-1">
                    {getAlertIcon(alert.type)}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-1">{alert.title}</h3>
                    <p className="text-gray-700 text-sm mb-2">{alert.message}</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span className="flex items-center">
                        <MapPin className="w-3 h-3 mr-1" />
                        {alert.location}
                      </span>
                      <span className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {alert.time}
                      </span>
                    </div>
                  </div>
                </div>
                <button className="text-gray-400 hover:text-gray-600 text-xs">
                  Dismiss
                </button>
              </div>
            </div>
          ))}
        </div>

        <button className="w-full mt-4 py-2 text-blue-600 hover:text-blue-700 text-sm font-medium">
          View All Alerts →
        </button>
      </div>

      {/* Geo-fencing Status */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">Geo-Fencing & Zone Monitoring</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium mb-3">Current Zone Status</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                <span className="text-sm">Tourist Safe Zone</span>
                <span className="bg-green-500 text-white px-2 py-1 rounded text-xs">ACTIVE</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <span className="text-sm">Commercial District</span>
                <span className="bg-blue-500 text-white px-2 py-1 rounded text-xs">MONITORED</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                <span className="text-sm">Construction Area</span>
                <span className="bg-yellow-500 text-white px-2 py-1 rounded text-xs">CAUTION</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-medium mb-3">Nearby Safe Zones</h3>
            <div className="space-y-2">
              {[
                { name: 'Police Station', distance: '0.2 mi', type: 'police' },
                { name: 'Hospital Emergency', distance: '0.5 mi', type: 'medical' },
                { name: 'Tourist Information', distance: '0.3 mi', type: 'info' },
                { name: 'Embassy Consulate', distance: '1.2 mi', type: 'embassy' }
              ].map((zone, index) => (
                <div key={index} className="flex items-center justify-between p-2 hover:bg-gray-50 rounded">
                  <span className="text-sm">{zone.name}</span>
                  <span className="text-xs text-gray-500">{zone.distance}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* AI Anomaly Detection */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4">AI Anomaly Detection</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-2">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-medium text-green-800">Route Monitoring</h3>
            <p className="text-sm text-green-600">Normal patterns detected</p>
          </div>
          
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-2">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-medium text-blue-800">Activity Tracking</h3>
            <p className="text-sm text-blue-600">Regular activity levels</p>
          </div>
          
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-2">
              <Bell className="w-6 h-6 text-white" />
            </div>
            <h3 className="font-medium text-green-800">Connection Status</h3>
            <p className="text-sm text-green-600">Strong signal detected</p>
          </div>
        </div>

        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600">
            <strong>AI Guardian:</strong> Your behavior patterns are being monitored for anomalies. 
            In case of route deviation, prolonged inactivity, or signal loss, automatic alerts will be sent to your emergency contacts.
          </p>
        </div>
      </div>
    </div>
  );
};