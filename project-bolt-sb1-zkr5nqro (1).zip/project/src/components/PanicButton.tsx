import React, { useState } from 'react';
import { AlertTriangle } from 'lucide-react';

export const PanicButton: React.FC = () => {
  const [isActive, setIsActive] = useState(false);

  const handlePanic = () => {
    setIsActive(true);
    // Simulate emergency alert
    alert('🚨 EMERGENCY ALERT ACTIVATED!\n\nYour location has been shared with:\n• Local Emergency Services\n• Your Emergency Contacts\n• Tourist Safety Authority\n\nHelp is on the way!');
    
    setTimeout(() => setIsActive(false), 3000);
  };

  return (
    <button
      onClick={handlePanic}
      className={`fixed bottom-6 right-6 z-50 w-16 h-16 rounded-full flex items-center justify-center text-white font-bold shadow-lg transform transition-all duration-200 hover:scale-110 active:scale-95 ${
        isActive 
          ? 'bg-red-700 animate-pulse' 
          : 'bg-red-600 hover:bg-red-700'
      }`}
      aria-label="Emergency SOS Panic Button"
    >
      <AlertTriangle className={`w-8 h-8 ${isActive ? 'animate-bounce' : ''}`} />
    </button>
  );
};