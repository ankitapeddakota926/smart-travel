import React, { useState, useRef, useEffect } from 'react';
import { Bot, Minimize2, Maximize2 } from 'lucide-react';
import { ChatInput } from './ChatInput';
import { ChatMessage, type ChatMessage as ChatMessageType } from './ChatMessage';

interface AIChatProps {
  isOpen: boolean;
  onToggle: () => void;
  className?: string;
}

export const AIChat: React.FC<AIChatProps> = ({
  isOpen,
  onToggle,
  className = ''
}) => {
  const [messages, setMessages] = useState<ChatMessageType[]>([
    {
      id: '1',
      sender: 'ai',
      text: 'Hello! I\'m your AI Travel Assistant. I can help you with:\n\n• Weather forecasts and alerts\n• Transportation options\n• Local attractions and events\n• Safety information\n• Emergency assistance\n• Real-time navigation\n\nHow can I assist you today?',
      timestamp: new Date(),
      actions: [
        { label: 'Check Weather', action: 'weather' },
        { label: 'Find Transport', action: 'transport' },
        { label: 'Safety Status', action: 'safety' }
      ]
    }
  ]);
  
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (text: string, attachments?: File[]) => {
    const userMessage: ChatMessageType = {
      id: Date.now().toString(),
      sender: 'user',
      text,
      timestamp: new Date(),
      attachments: attachments?.map(file => ({
        type: file.type.startsWith('image/') ? 'image' : 'file',
        name: file.name,
        url: URL.createObjectURL(file)
      }))
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      // Simulate AI processing with realistic delay
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
      
      const aiResponse = await generateAIResponse(text);
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('AI Chat Error:', error);
      const errorMessage: ChatMessageType = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: 'I apologize, but I\'m having trouble processing your request right now. Please try again or contact support if the issue persists.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateAIResponse = async (userInput: string): Promise<ChatMessageType> => {
    const input = userInput.toLowerCase();
    
    // Weather queries
    if (input.includes('weather') || input.includes('temperature') || input.includes('rain')) {
      return {
        id: Date.now().toString(),
        sender: 'ai',
        text: 'Based on current weather data for your location, here\'s what I found:',
        timestamp: new Date(),
        attachments: [{
          type: 'weather',
          data: {
            temperature: 22,
            condition: 'Partly Cloudy',
            humidity: 65,
            windSpeed: 12
          }
        }],
        actions: [
          { label: 'View 7-Day Forecast', action: 'forecast' },
          { label: 'Weather Alerts', action: 'weather-alerts' }
        ]
      };
    }

    // Transport queries
    if (input.includes('transport') || input.includes('taxi') || input.includes('bus') || input.includes('metro')) {
      return {
        id: Date.now().toString(),
        sender: 'ai',
        text: 'I found several transportation options near you:',
        timestamp: new Date(),
        attachments: [{
          type: 'transport',
          data: {
            name: 'City Taxi',
            eta: '3 min',
            price: '$8-12'
          }
        }],
        actions: [
          { label: 'Book Taxi', action: 'book-taxi' },
          { label: 'View All Options', action: 'transport-list' }
        ]
      };
    }

    // Safety queries
    if (input.includes('safety') || input.includes('safe') || input.includes('danger') || input.includes('emergency')) {
      return {
        id: Date.now().toString(),
        sender: 'ai',
        text: 'Your current safety status looks good! Here\'s a quick overview:\n\n• Current location: Safe zone\n• Safety score: 85/100\n• Nearest safe zone: 0.2 miles\n• Emergency services: Available\n\nIs there a specific safety concern I can help you with?',
        timestamp: new Date(),
        actions: [
          { label: 'View Safety Details', action: 'safety-details' },
          { label: 'Emergency Contacts', action: 'emergency' }
        ]
      };
    }

    // Location/directions queries
    if (input.includes('direction') || input.includes('navigate') || input.includes('route') || input.includes('how to get')) {
      return {
        id: Date.now().toString(),
        sender: 'ai',
        text: 'I can help you navigate safely! Where would you like to go? I\'ll provide the safest route with real-time updates.',
        timestamp: new Date(),
        actions: [
          { label: 'Share My Location', action: 'share-location' },
          { label: 'Find Nearby Places', action: 'nearby-places' }
        ]
      };
    }

    // Attractions/recommendations
    if (input.includes('attraction') || input.includes('restaurant') || input.includes('hotel') || input.includes('recommend')) {
      return {
        id: Date.now().toString(),
        sender: 'ai',
        text: 'I\'d be happy to recommend some great places! Based on your location and preferences, here are some top-rated options nearby:\n\n• Historic City Center (4.8★)\n• Local Cuisine House (4.6★)\n• Central Park Gardens (4.7★)\n\nWould you like more details about any of these, or are you looking for something specific?',
        timestamp: new Date(),
        actions: [
          { label: 'View Attractions', action: 'attractions' },
          { label: 'Find Restaurants', action: 'restaurants' },
          { label: 'Book Hotels', action: 'hotels' }
        ]
      };
    }

    // Default response with helpful suggestions
    return {
      id: Date.now().toString(),
      sender: 'ai',
      text: 'I understand you\'re looking for assistance. I can help you with various travel-related queries including weather updates, transportation options, safety information, local recommendations, and emergency support.\n\nCould you please be more specific about what you need help with?',
      timestamp: new Date(),
      actions: [
        { label: 'Weather Info', action: 'weather' },
        { label: 'Transportation', action: 'transport' },
        { label: 'Safety Check', action: 'safety' },
        { label: 'Local Guide', action: 'guide' }
      ]
    };
  };

  const handleActionClick = (action: string, data?: any) => {
    // Handle quick action buttons
    const actionMessage: ChatMessageType = {
      id: Date.now().toString(),
      sender: 'user',
      text: `Requested: ${action}`,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, actionMessage]);
    
    // Generate appropriate response based on action
    setTimeout(() => {
      handleSendMessage(action);
    }, 500);
  };

  const handleSendLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const locationMessage: ChatMessageType = {
            id: Date.now().toString(),
            sender: 'user',
            text: 'Shared my current location',
            timestamp: new Date(),
            attachments: [{
              type: 'location',
              data: {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
                address: 'Current Location'
              }
            }]
          };
          setMessages(prev => [...prev, locationMessage]);
        },
        (error) => {
          console.error('Location error:', error);
        }
      );
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={onToggle}
        className={`fixed bottom-20 right-6 z-40 w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 transition-all duration-200 hover:scale-110 flex items-center justify-center ${className}`}
      >
        <Bot className="w-6 h-6" />
      </button>
    );
  }

  return (
    <div className={`fixed bottom-6 right-6 z-40 w-96 h-[500px] bg-white rounded-xl shadow-2xl border border-gray-200 flex flex-col ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-blue-600 text-white rounded-t-xl">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-semibold">AI Travel Assistant</h3>
            <p className="text-xs text-blue-100">Online • Multilingual</p>
          </div>
        </div>
        
        <button
          onClick={onToggle}
          className="p-1 hover:bg-blue-500 rounded transition-colors"
        >
          <Minimize2 className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <ChatMessage
            key={message.id}
            message={message}
            onActionClick={handleActionClick}
          />
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-lg p-3 max-w-xs">
              <div className="flex items-center space-x-2">
                <Bot className="w-4 h-4 text-blue-600" />
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <ChatInput
        onSendMessage={handleSendMessage}
        onSendLocation={handleSendLocation}
        disabled={isLoading}
      />
    </div>
  );
};