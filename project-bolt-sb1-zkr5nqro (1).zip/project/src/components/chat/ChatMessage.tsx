import React from 'react';
import { Bot, User, MapPin, Clock, Download, ExternalLink } from 'lucide-react';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: Date;
  attachments?: {
    type: 'image' | 'file' | 'location' | 'weather' | 'transport';
    url?: string;
    name?: string;
    data?: any;
  }[];
  actions?: {
    label: string;
    action: string;
    data?: any;
  }[];
}

interface ChatMessageProps {
  message: ChatMessage;
  onActionClick?: (action: string, data?: any) => void;
  className?: string;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  onActionClick,
  className = ''
}) => {
  const isUser = message.sender === 'user';

  const renderAttachment = (attachment: ChatMessage['attachments'][0], index: number) => {
    switch (attachment.type) {
      case 'image':
        return (
          <img
            key={index}
            src={attachment.url}
            alt={attachment.name}
            className="max-w-xs rounded-lg shadow-sm"
          />
        );
      
      case 'location':
        return (
          <div key={index} className="bg-blue-50 border border-blue-200 rounded-lg p-3 max-w-xs">
            <div className="flex items-center space-x-2 mb-2">
              <MapPin className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">Location Shared</span>
            </div>
            {attachment.data && (
              <p className="text-sm text-blue-700">{attachment.data.address}</p>
            )}
          </div>
        );
      
      case 'weather':
        return (
          <div key={index} className="bg-gradient-to-r from-blue-400 to-blue-600 text-white rounded-lg p-4 max-w-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Weather Update</span>
              <span className="text-2xl font-bold">{attachment.data?.temperature}°C</span>
            </div>
            <p className="text-sm opacity-90">{attachment.data?.condition}</p>
          </div>
        );
      
      case 'transport':
        return (
          <div key={index} className="bg-green-50 border border-green-200 rounded-lg p-3 max-w-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium text-green-800">{attachment.data?.name}</span>
              <span className="text-sm text-green-600">{attachment.data?.eta}</span>
            </div>
            <p className="text-sm text-green-700">{attachment.data?.price}</p>
          </div>
        );
      
      default:
        return (
          <div key={index} className="bg-gray-50 border border-gray-200 rounded-lg p-3 max-w-xs">
            <div className="flex items-center space-x-2">
              <Download className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-700">{attachment.name}</span>
            </div>
          </div>
        );
    }
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} ${className}`}>
      <div className={`max-w-xs lg:max-w-md ${isUser ? 'order-2' : 'order-1'}`}>
        <div
          className={`px-4 py-3 rounded-lg ${
            isUser
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-800'
          }`}
        >
          <div className="flex items-start space-x-2">
            <div className={`mt-1 ${isUser ? 'order-2' : 'order-1'}`}>
              {isUser ? (
                <User className="w-4 h-4 text-white" />
              ) : (
                <Bot className="w-4 h-4 text-blue-600" />
              )}
            </div>
            
            <div className={`flex-1 ${isUser ? 'order-1' : 'order-2'}`}>
              {message.text && (
                <p className="text-sm whitespace-pre-wrap">{message.text}</p>
              )}
              
              {message.attachments && message.attachments.length > 0 && (
                <div className="mt-2 space-y-2">
                  {message.attachments.map(renderAttachment)}
                </div>
              )}
              
              <div className="flex items-center justify-between mt-2">
                <p className={`text-xs ${
                  isUser ? 'text-blue-100' : 'text-gray-500'
                }`}>
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        {message.actions && message.actions.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-2">
            {message.actions.map((action, index) => (
              <button
                key={index}
                onClick={() => onActionClick?.(action.action, action.data)}
                className="px-3 py-1 bg-white border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors flex items-center space-x-1"
              >
                <span>{action.label}</span>
                <ExternalLink className="w-3 h-3" />
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};