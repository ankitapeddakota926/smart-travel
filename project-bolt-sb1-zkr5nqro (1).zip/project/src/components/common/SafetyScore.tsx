import React from 'react';
import { Shield, TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';

interface SafetyScoreProps {
  score: number;
  previousScore?: number;
  factors?: {
    location: number;
    timeOfDay: number;
    crowdLevel: number;
    weatherCondition: number;
  };
  className?: string;
  showDetails?: boolean;
  onDetailsClick?: () => void;
}

export const SafetyScore: React.FC<SafetyScoreProps> = ({
  score,
  previousScore,
  factors,
  className = '',
  showDetails = true,
  onDetailsClick
}) => {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBackground = (score: number) => {
    if (score >= 80) return 'from-green-400 to-green-600';
    if (score >= 60) return 'from-yellow-400 to-yellow-600';
    return 'from-red-400 to-red-600';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Safe';
    if (score >= 60) return 'Moderate';
    return 'High Risk';
  };

  const getTrend = () => {
    if (!previousScore) return null;
    const diff = score - previousScore;
    if (diff > 0) return { icon: TrendingUp, color: 'text-green-500', text: `+${diff}` };
    if (diff < 0) return { icon: TrendingDown, color: 'text-red-500', text: `${diff}` };
    return null;
  };

  const trend = getTrend();

  return (
    <div className={`bg-white rounded-xl shadow-sm border border-gray-100 p-6 ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold flex items-center">
          <Shield className="w-5 h-5 mr-2 text-blue-600" />
          Safety Score
        </h3>
        
        {trend && (
          <div className={`flex items-center space-x-1 ${trend.color}`}>
            <trend.icon className="w-4 h-4" />
            <span className="text-sm font-medium">{trend.text}</span>
          </div>
        )}
      </div>

      <div className="relative mb-6">
        <div className={`w-32 h-32 rounded-full bg-gradient-to-br ${getScoreBackground(score)} flex items-center justify-center mx-auto shadow-lg`}>
          <div className="text-center text-white">
            <div className="text-3xl font-bold">{score}</div>
            <div className="text-sm opacity-90">/ 100</div>
          </div>
        </div>
        
        <div className="text-center mt-3">
          <p className={`font-semibold ${getScoreColor(score)}`}>
            {getScoreLabel(score)}
          </p>
        </div>
      </div>

      {factors && showDetails && (
        <div className="space-y-3">
          <h4 className="font-medium text-gray-700">Contributing Factors</h4>
          
          {Object.entries(factors).map(([key, value]) => (
            <div key={key} className="flex items-center justify-between">
              <span className="text-sm text-gray-600 capitalize">
                {key.replace(/([A-Z])/g, ' $1').trim()}
              </span>
              <div className="flex items-center space-x-2">
                <div className="w-16 bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      value >= 80 ? 'bg-green-500' :
                      value >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${value}%` }}
                  />
                </div>
                <span className="text-sm font-medium w-8">{value}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {onDetailsClick && (
        <button
          onClick={onDetailsClick}
          className="w-full mt-4 py-2 text-blue-600 hover:text-blue-700 text-sm font-medium border-t pt-4"
        >
          View Detailed Analysis →
        </button>
      )}

      {score < 60 && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
            <div className="text-sm text-red-700">
              <p className="font-medium">Safety Alert</p>
              <p>Consider moving to a safer area or contacting authorities.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};