import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface PageNavigatorProps {
  className?: string;
  showLabels?: boolean;
}

export const PageNavigator: React.FC<PageNavigatorProps> = ({ 
  className = '', 
  showLabels = true 
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleBack = () => {
    navigate(-1);
  };

  const handleForward = () => {
    navigate(1);
  };

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <button
        onClick={handleBack}
        className="flex items-center space-x-1 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200 shadow-sm hover:shadow-md"
        aria-label="Go back"
      >
        <ChevronLeft className="w-4 h-4" />
        {showLabels && <span className="text-sm font-medium">Back</span>}
      </button>
      
      <button
        onClick={handleForward}
        className="flex items-center space-x-1 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-all duration-200 shadow-sm hover:shadow-md"
        aria-label="Go forward"
      >
        {showLabels && <span className="text-sm font-medium">Forward</span>}
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
};