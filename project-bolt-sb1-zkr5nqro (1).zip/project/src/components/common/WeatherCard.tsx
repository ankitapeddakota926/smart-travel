import React from 'react';
import { Cloud, Sun, CloudRain, AlertTriangle, Thermometer, Wind, Droplets } from 'lucide-react';

interface WeatherData {
  temperature: number;
  condition: 'sunny' | 'cloudy' | 'rainy' | 'stormy';
  humidity: number;
  windSpeed: number;
  location: string;
  alerts?: string[];
}

interface WeatherCardProps {
  data: WeatherData;
  className?: string;
  compact?: boolean;
  onAlertClick?: (alert: string) => void;
}

export const WeatherCard: React.FC<WeatherCardProps> = ({
  data,
  className = '',
  compact = false,
  onAlertClick
}) => {
  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case 'sunny': return <Sun className="w-8 h-8 text-yellow-500" />;
      case 'cloudy': return <Cloud className="w-8 h-8 text-gray-500" />;
      case 'rainy': return <CloudRain className="w-8 h-8 text-blue-500" />;
      case 'stormy': return <AlertTriangle className="w-8 h-8 text-red-500" />;
      default: return <Sun className="w-8 h-8 text-yellow-500" />;
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'sunny': return 'from-yellow-400 to-orange-500';
      case 'cloudy': return 'from-gray-400 to-gray-600';
      case 'rainy': return 'from-blue-400 to-blue-600';
      case 'stormy': return 'from-red-400 to-red-600';
      default: return 'from-blue-400 to-blue-600';
    }
  };

  if (compact) {
    return (
      <div className={`bg-white rounded-lg shadow-sm border border-gray-100 p-4 ${className}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {getWeatherIcon(data.condition)}
            <div>
              <p className="font-semibold text-lg">{data.temperature}°C</p>
              <p className="text-sm text-gray-600 capitalize">{data.condition}</p>
            </div>
          </div>
          {data.alerts && data.alerts.length > 0 && (
            <AlertTriangle className="w-5 h-5 text-red-500" />
          )}
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden ${className}`}>
      <div className={`bg-gradient-to-r ${getConditionColor(data.condition)} p-6 text-white`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl font-semibold">{data.location}</h3>
            <p className="text-sm opacity-90">Current Weather</p>
          </div>
          {getWeatherIcon(data.condition)}
        </div>
        
        <div className="flex items-end space-x-2">
          <span className="text-4xl font-bold">{data.temperature}°</span>
          <span className="text-lg opacity-90 mb-1">C</span>
        </div>
        <p className="capitalize text-sm opacity-90">{data.condition}</p>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center space-x-2">
            <Droplets className="w-4 h-4 text-blue-500" />
            <div>
              <p className="text-sm text-gray-600">Humidity</p>
              <p className="font-semibold">{data.humidity}%</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Wind className="w-4 h-4 text-gray-500" />
            <div>
              <p className="text-sm text-gray-600">Wind Speed</p>
              <p className="font-semibold">{data.windSpeed} km/h</p>
            </div>
          </div>
        </div>

        {data.alerts && data.alerts.length > 0 && (
          <div className="border-t pt-4">
            <h4 className="font-medium text-red-600 mb-2 flex items-center">
              <AlertTriangle className="w-4 h-4 mr-1" />
              Weather Alerts
            </h4>
            <div className="space-y-2">
              {data.alerts.map((alert, index) => (
                <button
                  key={index}
                  onClick={() => onAlertClick?.(alert)}
                  className="w-full text-left p-2 bg-red-50 border border-red-200 rounded-lg text-sm text-red-800 hover:bg-red-100 transition-colors"
                >
                  {alert}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};