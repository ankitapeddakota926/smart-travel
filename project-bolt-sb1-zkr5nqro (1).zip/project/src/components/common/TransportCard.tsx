import React from 'react';
import { Car, Bus, Train, MapPin, Clock, DollarSign, Users, Star } from 'lucide-react';

interface TransportOption {
  id: string;
  type: 'taxi' | 'bus' | 'metro' | 'rideshare' | 'bike';
  name: string;
  eta: string;
  price: string;
  available: number;
  rating?: number;
  distance?: string;
  route?: string;
}

interface TransportCardProps {
  transport: TransportOption;
  className?: string;
  compact?: boolean;
  onBook?: (transportId: string) => void;
  onViewRoute?: (transportId: string) => void;
}

export const TransportCard: React.FC<TransportCardProps> = ({
  transport,
  className = '',
  compact = false,
  onBook,
  onViewRoute
}) => {
  const getTransportIcon = (type: string) => {
    switch (type) {
      case 'taxi': return <Car className="w-6 h-6 text-yellow-500" />;
      case 'bus': return <Bus className="w-6 h-6 text-blue-500" />;
      case 'metro': return <Train className="w-6 h-6 text-green-500" />;
      case 'rideshare': return <Car className="w-6 h-6 text-purple-500" />;
      case 'bike': return <Car className="w-6 h-6 text-orange-500" />;
      default: return <Car className="w-6 h-6 text-gray-500" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'taxi': return 'bg-yellow-50 border-yellow-200';
      case 'bus': return 'bg-blue-50 border-blue-200';
      case 'metro': return 'bg-green-50 border-green-200';
      case 'rideshare': return 'bg-purple-50 border-purple-200';
      case 'bike': return 'bg-orange-50 border-orange-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  if (compact) {
    return (
      <div className={`bg-white rounded-lg shadow-sm border border-gray-100 p-4 ${className}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {getTransportIcon(transport.type)}
            <div>
              <p className="font-semibold">{transport.name}</p>
              <p className="text-sm text-gray-600">{transport.eta} • {transport.price}</p>
            </div>
          </div>
          <button
            onClick={() => onBook?.(transport.id)}
            className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700 transition-colors text-sm"
          >
            Book
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow ${className}`}>
      <div className={`p-4 border-l-4 ${getTypeColor(transport.type)}`}>
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            {getTransportIcon(transport.type)}
            <div>
              <h3 className="font-semibold text-lg">{transport.name}</h3>
              <p className="text-sm text-gray-600 capitalize">{transport.type}</p>
            </div>
          </div>
          
          <div className="text-right">
            <span className="bg-gray-100 px-2 py-1 rounded text-sm">
              {transport.available} available
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-gray-500" />
            <div>
              <p className="text-sm text-gray-600">ETA</p>
              <p className="font-semibold">{transport.eta}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <DollarSign className="w-4 h-4 text-gray-500" />
            <div>
              <p className="text-sm text-gray-600">Price</p>
              <p className="font-semibold">{transport.price}</p>
            </div>
          </div>
        </div>

        {transport.rating && (
          <div className="flex items-center space-x-1 mb-4">
            <Star className="w-4 h-4 text-yellow-500 fill-current" />
            <span className="text-sm font-medium">{transport.rating}</span>
            <span className="text-sm text-gray-500">rating</span>
          </div>
        )}

        {transport.route && (
          <div className="flex items-center space-x-2 mb-4 text-sm text-gray-600">
            <MapPin className="w-4 h-4" />
            <span>{transport.route}</span>
          </div>
        )}

        <div className="flex space-x-2">
          <button
            onClick={() => onBook?.(transport.id)}
            className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Book Now
          </button>
          
          {onViewRoute && (
            <button
              onClick={() => onViewRoute(transport.id)}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <MapPin className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};