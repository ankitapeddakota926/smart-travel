import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { SIDEBAR_ITEMS } from '../utils/constants';

export const Breadcrumb: React.FC = () => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter(x => x);

  const getBreadcrumbName = (path: string) => {
    const item = SIDEBAR_ITEMS.find(item => item.path === `/${path}`);
    return item?.label || path.charAt(0).toUpperCase() + path.slice(1);
  };

  return (
    <nav className="flex items-center space-x-1 text-sm text-gray-600 mb-6">
      <Link to="/" className="hover:text-blue-600 flex items-center">
        <Home className="w-4 h-4" />
      </Link>
      
      {pathnames.map((name, index) => {
        const routeTo = `/${pathnames.slice(0, index + 1).join('/')}`;
        const isLast = index === pathnames.length - 1;
        
        return (
          <React.Fragment key={name}>
            <ChevronRight className="w-4 h-4 text-gray-400" />
            {isLast ? (
              <span className="text-gray-800 font-medium">
                {getBreadcrumbName(name)}
              </span>
            ) : (
              <Link to={routeTo} className="hover:text-blue-600">
                {getBreadcrumbName(name)}
              </Link>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
};