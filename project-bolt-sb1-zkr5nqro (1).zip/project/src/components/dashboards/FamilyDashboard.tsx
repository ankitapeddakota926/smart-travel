import React, { useState } from 'react';
import { 
  Users, MapPin, Shield, Clock, 
  Phone, AlertTriangle, Heart, Bell 
} from 'lucide-react';

interface FamilyMember {
  id: string;
  name: string;
  digitalId: string;
  location: string;
  safetyScore: number;
  lastSeen: Date;
  status: 'safe' | 'caution' | 'emergency';
}

interface LocationUpdate {
  id: string;
  memberId: string;
  memberName: string;
  location: string;
  timestamp: Date;
  type: 'check-in' | 'movement' | 'alert';
}

export const FamilyDashboard: React.FC = () => {
  const [selectedMember, setSelectedMember] = useState<string | null>(null);

  const familyMembers: FamilyMember[] = [
    {
      id: '1',
      name: 'John Tourist',
      digitalId: 'DID-2024-001',
      location: 'Times Square, NYC',
      safetyScore: 85,
      lastSeen: new Date(Date.now() - 5 * 60 * 1000),
      status: 'safe'
    },
    {
      id: '2',
      name: 'Sarah Tourist',
      digitalId: 'DID-2024-002',
      location: 'Central Park, NYC',
      safetyScore: 92,
      lastSeen: new Date(Date.now() - 2 * 60 * 1000),
      status: 'safe'
    },
    {
      id: '3',
      name: 'Mike Tourist Jr.',
      digitalId: 'DID-2024-003',
      location: 'Brooklyn Bridge, NYC',
      safetyScore: 78,
      lastSeen: new Date(Date.now() - 15 * 60 * 1000),
      status: 'caution'
    }
  ];

  const locationUpdates: LocationUpdate[] = [
    {
      id: '1',
      memberId: '1',
      memberName: 'John Tourist',
      location: 'Times Square, NYC',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      type: 'check-in'
    },
    {
      id: '2',
      memberId: '2',
      memberName: 'Sarah Tourist',
      location: 'Central Park, NYC',
      timestamp: new Date(Date.now() - 2 * 60 * 1000),
      type: 'movement'
    },
    {
      id: '3',
      memberId: '3',
      memberName: 'Mike Tourist Jr.',
      location: 'Brooklyn Bridge, NYC',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      type: 'alert'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'safe': return 'bg-green-100 text-green-800 border-green-200';
      case 'caution': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'emergency': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getUpdateTypeIcon = (type: string) => {
    switch (type) {
      case 'check-in': return <Shield className="w-4 h-4 text-green-500" />;
      case 'movement': return <MapPin className="w-4 h-4 text-blue-500" />;
      case 'alert': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default: return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  const stats = [
    { label: 'Family Members', value: familyMembers.length, icon: Users, color: 'blue' },
    { label: 'All Safe', value: familyMembers.filter(m => m.status === 'safe').length, icon: Shield, color: 'green' },
    { label: 'Avg Safety Score', value: Math.round(familyMembers.reduce((acc, m) => acc + m.safetyScore, 0) / familyMembers.length), icon: Heart, color: 'purple' },
    { label: 'Last Update', value: '2m ago', icon: Clock, color: 'gray' }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white p-8 rounded-2xl shadow-lg">
        <h1 className="text-3xl font-bold mb-2">Family Safety Monitor</h1>
        <p className="text-purple-100 mb-4">
          Keep track of your family members' safety and location in real-time
        </p>
        <div className="flex items-center space-x-4 text-sm">
          <span className="bg-purple-500 px-3 py-1 rounded-full">
            Family Group: Tourist Family
          </span>
          <span className="bg-green-500 px-3 py-1 rounded-full">
            All Members: Safe
          </span>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-2 rounded-lg ${
                  stat.color === 'blue' ? 'bg-blue-100' :
                  stat.color === 'green' ? 'bg-green-100' :
                  stat.color === 'purple' ? 'bg-purple-100' :
                  'bg-gray-100'
                }`}>
                  <Icon className={`w-5 h-5 ${
                    stat.color === 'blue' ? 'text-blue-600' :
                    stat.color === 'green' ? 'text-green-600' :
                    stat.color === 'purple' ? 'text-purple-600' :
                    'text-gray-600'
                  }`} />
                </div>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Family Members */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Users className="w-5 h-5 mr-2 text-purple-600" />
            Family Members
          </h2>

          <div className="space-y-4">
            {familyMembers.map((member) => (
              <div
                key={member.id}
                className={`p-4 rounded-lg border cursor-pointer transition-colors ${
                  selectedMember === member.id ? 'bg-purple-50 border-purple-200' : 'hover:bg-gray-50'
                }`}
                onClick={() => setSelectedMember(member.id)}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold">{member.name}</h3>
                    <p className="text-sm text-gray-600">{member.digitalId}</p>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs border ${getStatusColor(member.status)}`}>
                    {member.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div>
                    <p className="text-xs text-gray-500">Location</p>
                    <p className="text-sm font-medium">{member.location}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Safety Score</p>
                    <p className={`text-sm font-bold ${getScoreColor(member.safetyScore)}`}>
                      {member.safetyScore}/100
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span className="flex items-center">
                    <Clock className="w-3 h-3 mr-1" />
                    Last seen: {member.lastSeen.toLocaleTimeString()}
                  </span>
                  <div className="flex space-x-2">
                    <button className="text-blue-600 hover:text-blue-700">
                      <MapPin className="w-4 h-4" />
                    </button>
                    <button className="text-green-600 hover:text-green-700">
                      <Phone className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Location Updates */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <MapPin className="w-5 h-5 mr-2 text-blue-600" />
            Recent Location Updates
          </h2>

          <div className="space-y-4">
            {locationUpdates.map((update) => (
              <div key={update.id} className="border-l-4 border-blue-200 pl-4 py-2">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getUpdateTypeIcon(update.type)}
                    <div>
                      <p className="font-medium text-sm">{update.memberName}</p>
                      <p className="text-xs text-gray-600 capitalize">{update.type}</p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">
                    {update.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                <p className="text-sm text-gray-700 ml-6">{update.location}</p>
              </div>
            ))}
          </div>

          <button className="w-full mt-4 py-2 text-blue-600 hover:text-blue-700 text-sm font-medium border-t pt-4">
            View Location History →
          </button>
        </div>
      </div>

      {/* Family Map */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <MapPin className="w-5 h-5 mr-2 text-red-600" />
          Family Location Map
        </h2>
        
        <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center mb-4">
          <div className="text-center">
            <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-600">Real-time family member locations</p>
            <p className="text-sm text-gray-500">Interactive map showing all family members and their safety zones</p>
          </div>
        </div>

        <div className="flex justify-between items-center">
          <div className="flex space-x-4 text-sm">
            <span className="flex items-center"><div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div> Safe Members</span>
            <span className="flex items-center"><div className="w-3 h-3 bg-yellow-500 rounded-full mr-1"></div> Caution</span>
            <span className="flex items-center"><div className="w-3 h-3 bg-red-500 rounded-full mr-1"></div> Emergency</span>
          </div>
          <div className="flex space-x-2">
            <button className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors text-sm">
              Send Group Message
            </button>
            <button className="border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
              Emergency Alert
            </button>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-semibold mb-4 flex items-center">
            <Bell className="w-5 h-5 mr-2 text-yellow-600" />
            Notifications
          </h3>
          <div className="space-y-2">
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Set Safety Alerts
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Location Reminders
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Check-in Schedules
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-semibold mb-4 flex items-center">
            <Shield className="w-5 h-5 mr-2 text-green-600" />
            Safety Settings
          </h3>
          <div className="space-y-2">
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Geo-fence Boundaries
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Emergency Contacts
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Safe Zone Preferences
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-semibold mb-4 flex items-center">
            <Phone className="w-5 h-5 mr-2 text-blue-600" />
            Communication
          </h3>
          <div className="space-y-2">
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Group Chat
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Video Call
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Share Itinerary
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};