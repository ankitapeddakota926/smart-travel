import React, { useState } from 'react';
import { 
  Users, AlertTriangle, MapPin, TrendingUp, 
  Shield, Clock, FileText, Bell 
} from 'lucide-react';

interface TouristCluster {
  id: string;
  location: string;
  count: number;
  riskLevel: 'low' | 'medium' | 'high';
  alerts: number;
}

interface EmergencyAlert {
  id: string;
  type: 'sos' | 'medical' | 'security' | 'weather';
  location: string;
  tourist: string;
  timestamp: Date;
  status: 'active' | 'responding' | 'resolved';
}

export const AuthorityDashboard: React.FC = () => {
  const [selectedCluster, setSelectedCluster] = useState<string | null>(null);

  const touristClusters: TouristCluster[] = [
    { id: '1', location: 'Times Square', count: 245, riskLevel: 'medium', alerts: 3 },
    { id: '2', location: 'Central Park', count: 189, riskLevel: 'low', alerts: 1 },
    { id: '3', location: 'Brooklyn Bridge', count: 156, riskLevel: 'low', alerts: 0 },
    { id: '4', location: 'Chinatown', count: 98, riskLevel: 'high', alerts: 7 }
  ];

  const emergencyAlerts: EmergencyAlert[] = [
    {
      id: '1',
      type: 'sos',
      location: 'Times Square, NYC',
      tourist: 'John D. (DID-2024-001)',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      status: 'active'
    },
    {
      id: '2',
      type: 'medical',
      location: 'Central Park, NYC',
      tourist: 'Sarah M. (DID-2024-045)',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      status: 'responding'
    },
    {
      id: '3',
      type: 'security',
      location: 'Brooklyn Bridge, NYC',
      tourist: 'Mike C. (DID-2024-078)',
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      status: 'resolved'
    }
  ];

  const stats = [
    { label: 'Active Tourists', value: 1247, change: '+12%', icon: Users, color: 'blue' },
    { label: 'Active Alerts', value: 23, change: '-8%', icon: AlertTriangle, color: 'red' },
    { label: 'Safe Zones', value: 45, change: '+2', icon: Shield, color: 'green' },
    { label: 'Response Time', value: '3.2m', change: '-15%', icon: Clock, color: 'purple' }
  ];

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-green-100 text-green-800 border-green-200';
    }
  };

  const getAlertTypeIcon = (type: string) => {
    switch (type) {
      case 'sos': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'medical': return <Shield className="w-4 h-4 text-blue-500" />;
      case 'security': return <Shield className="w-4 h-4 text-orange-500" />;
      default: return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-red-100 text-red-800';
      case 'responding': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-green-100 text-green-800';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white p-8 rounded-2xl shadow-lg">
        <h1 className="text-3xl font-bold mb-2">Authority Control Center</h1>
        <p className="text-indigo-100 mb-4">
          Real-time monitoring and emergency response coordination
        </p>
        <div className="flex items-center space-x-4 text-sm">
          <span className="bg-indigo-500 px-3 py-1 rounded-full">
            Region: New York City
          </span>
          <span className="bg-green-500 px-3 py-1 rounded-full">
            System Status: Online
          </span>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-2 rounded-lg ${
                  stat.color === 'blue' ? 'bg-blue-100' :
                  stat.color === 'red' ? 'bg-red-100' :
                  stat.color === 'green' ? 'bg-green-100' :
                  'bg-purple-100'
                }`}>
                  <Icon className={`w-5 h-5 ${
                    stat.color === 'blue' ? 'text-blue-600' :
                    stat.color === 'red' ? 'text-red-600' :
                    stat.color === 'green' ? 'text-green-600' :
                    'text-purple-600'
                  }`} />
                </div>
                <span className={`text-xs px-2 py-1 rounded ${
                  stat.change.startsWith('+') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  {stat.change}
                </span>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Tourist Clusters Map */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <MapPin className="w-5 h-5 mr-2 text-blue-600" />
            Tourist Clusters & Heat Map
          </h2>
          
          <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center mb-4">
            <div className="text-center">
              <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600">Real-time tourist distribution map</p>
              <p className="text-sm text-gray-500">Heat map showing tourist density and risk levels</p>
            </div>
          </div>

          <div className="space-y-2">
            {touristClusters.map((cluster) => (
              <div
                key={cluster.id}
                className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                  selectedCluster === cluster.id ? 'bg-blue-50 border-blue-200' : 'hover:bg-gray-50'
                }`}
                onClick={() => setSelectedCluster(cluster.id)}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{cluster.location}</p>
                    <p className="text-sm text-gray-600">{cluster.count} tourists</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-1 rounded text-xs border ${getRiskColor(cluster.riskLevel)}`}>
                      {cluster.riskLevel} risk
                    </span>
                    {cluster.alerts > 0 && (
                      <span className="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">
                        {cluster.alerts} alerts
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Emergency Alerts */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <AlertTriangle className="w-5 h-5 mr-2 text-red-600" />
            Emergency Alerts & Response
          </h2>

          <div className="space-y-4">
            {emergencyAlerts.map((alert) => (
              <div key={alert.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    {getAlertTypeIcon(alert.type)}
                    <div>
                      <p className="font-medium capitalize">{alert.type} Alert</p>
                      <p className="text-sm text-gray-600">{alert.location}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs ${getStatusColor(alert.status)}`}>
                    {alert.status}
                  </span>
                </div>
                
                <div className="text-sm text-gray-600 mb-3">
                  <p>Tourist: {alert.tourist}</p>
                  <p>Time: {alert.timestamp.toLocaleTimeString()}</p>
                </div>

                <div className="flex space-x-2">
                  <button className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition-colors">
                    View Details
                  </button>
                  <button className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 transition-colors">
                    Dispatch Unit
                  </button>
                  <button className="border border-gray-300 px-3 py-1 rounded text-sm hover:bg-gray-50 transition-colors">
                    Generate e-FIR
                  </button>
                </div>
              </div>
            ))}
          </div>

          <button className="w-full mt-4 py-2 text-blue-600 hover:text-blue-700 text-sm font-medium border-t pt-4">
            View All Emergency Reports →
          </button>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-semibold mb-4 flex items-center">
            <FileText className="w-5 h-5 mr-2 text-blue-600" />
            Generate Reports
          </h3>
          <div className="space-y-2">
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Daily Safety Report
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Tourist Activity Summary
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Emergency Response Analytics
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-semibold mb-4 flex items-center">
            <Bell className="w-5 h-5 mr-2 text-yellow-600" />
            Alert Management
          </h3>
          <div className="space-y-2">
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Broadcast Safety Alert
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Update Zone Status
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Weather Warnings
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-semibold mb-4 flex items-center">
            <Users className="w-5 h-5 mr-2 text-green-600" />
            Resource Management
          </h3>
          <div className="space-y-2">
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Deploy Response Units
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Update Safe Zones
            </button>
            <button className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm">
              Coordinate with Agencies
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};