import React, { useState } from 'react';
import { 
  BarChart3, Users, Shield, Settings, 
  Database, Activity, AlertTriangle, TrendingUp 
} from 'lucide-react';

interface SystemMetric {
  label: string;
  value: string | number;
  change: string;
  trend: 'up' | 'down' | 'stable';
}

interface UserActivity {
  id: string;
  action: string;
  user: string;
  timestamp: Date;
  status: 'success' | 'warning' | 'error';
}

export const AdminDashboard: React.FC = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('24h');

  const systemMetrics: SystemMetric[] = [
    { label: 'Total Users', value: 12847, change: '+12%', trend: 'up' },
    { label: 'Active Sessions', value: 3421, change: '+8%', trend: 'up' },
    { label: 'System Uptime', value: '99.9%', change: 'Stable', trend: 'stable' },
    { label: 'Response Time', value: '120ms', change: '-15%', trend: 'down' },
    { label: 'Emergency Alerts', value: 23, change: '-8%', trend: 'down' },
    { label: 'Data Storage', value: '2.4TB', change: '+5%', trend: 'up' }
  ];

  const userActivity: UserActivity[] = [
    {
      id: '1',
      action: 'Emergency SOS Activated',
      user: 'Tourist (DID-2024-001)',
      timestamp: new Date(Date.now() - 5 * 60 * 1000),
      status: 'warning'
    },
    {
      id: '2',
      action: 'New User Registration',
      user: 'Sarah M. (DID-2024-156)',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      status: 'success'
    },
    {
      id: '3',
      action: 'System Backup Completed',
      user: 'System',
      timestamp: new Date(Date.now() - 30 * 60 * 1000),
      status: 'success'
    },
    {
      id: '4',
      action: 'API Rate Limit Exceeded',
      user: 'Weather Service',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      status: 'error'
    }
  ];

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down': return <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />;
      default: return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'error': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-800 to-gray-900 text-white p-8 rounded-2xl shadow-lg">
        <h1 className="text-3xl font-bold mb-2">System Administration</h1>
        <p className="text-gray-300 mb-4">
          Monitor and manage the Smart Tourist Safety System
        </p>
        <div className="flex items-center space-x-4 text-sm">
          <span className="bg-gray-700 px-3 py-1 rounded-full">
            Environment: Production
          </span>
          <span className="bg-green-500 px-3 py-1 rounded-full">
            Status: All Systems Operational
          </span>
        </div>
      </div>

      {/* Time Frame Selector */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">System Overview</h2>
        <div className="flex space-x-2">
          {['1h', '24h', '7d', '30d'].map((timeframe) => (
            <button
              key={timeframe}
              onClick={() => setSelectedTimeframe(timeframe)}
              className={`px-3 py-1 rounded text-sm ${
                selectedTimeframe === timeframe
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {timeframe}
            </button>
          ))}
        </div>
      </div>

      {/* System Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {systemMetrics.map((metric, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-blue-100 rounded-lg">
                <BarChart3 className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex items-center space-x-1">
                {getTrendIcon(metric.trend)}
                <span className={`text-xs ${
                  metric.trend === 'up' ? 'text-green-600' :
                  metric.trend === 'down' ? 'text-red-600' : 'text-gray-600'
                }`}>
                  {metric.change}
                </span>
              </div>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
              <p className="text-sm text-gray-600">{metric.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* System Activity */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Activity className="w-5 h-5 mr-2 text-blue-600" />
            Recent System Activity
          </h3>

          <div className="space-y-4">
            {userActivity.map((activity) => (
              <div key={activity.id} className="flex items-start justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <p className="font-medium text-sm">{activity.action}</p>
                  <p className="text-xs text-gray-600">{activity.user}</p>
                  <p className="text-xs text-gray-500">{activity.timestamp.toLocaleString()}</p>
                </div>
                <span className={`px-2 py-1 rounded text-xs ${getStatusColor(activity.status)}`}>
                  {activity.status}
                </span>
              </div>
            ))}
          </div>

          <button className="w-full mt-4 py-2 text-blue-600 hover:text-blue-700 text-sm font-medium border-t pt-4">
            View Full Activity Log →
          </button>
        </div>

        {/* System Health */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold mb-4 flex items-center">
            <Shield className="w-5 h-5 mr-2 text-green-600" />
            System Health
          </h3>

          <div className="space-y-4">
            {[
              { service: 'API Gateway', status: 'healthy', uptime: '99.9%' },
              { service: 'Database', status: 'healthy', uptime: '99.8%' },
              { service: 'Authentication', status: 'healthy', uptime: '100%' },
              { service: 'AI Services', status: 'warning', uptime: '98.5%' },
              { service: 'Blockchain Network', status: 'healthy', uptime: '99.7%' },
              { service: 'Emergency System', status: 'healthy', uptime: '100%' }
            ].map((service, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-sm">{service.service}</p>
                  <p className="text-xs text-gray-600">Uptime: {service.uptime}</p>
                </div>
                <span className={`px-2 py-1 rounded text-xs ${
                  service.status === 'healthy' ? 'bg-green-100 text-green-800' :
                  service.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {service.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Management Tools */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="p-3 bg-blue-100 rounded-lg w-fit mb-4">
            <Users className="w-6 h-6 text-blue-600" />
          </div>
          <h3 className="font-semibold mb-2">User Management</h3>
          <p className="text-sm text-gray-600 mb-4">Manage user accounts, roles, and permissions</p>
          <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
            Manage Users
          </button>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="p-3 bg-green-100 rounded-lg w-fit mb-4">
            <Database className="w-6 h-6 text-green-600" />
          </div>
          <h3 className="font-semibold mb-2">Database Admin</h3>
          <p className="text-sm text-gray-600 mb-4">Monitor database performance and backups</p>
          <button className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors text-sm">
            Database Tools
          </button>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="p-3 bg-yellow-100 rounded-lg w-fit mb-4">
            <AlertTriangle className="w-6 h-6 text-yellow-600" />
          </div>
          <h3 className="font-semibold mb-2">Alert System</h3>
          <p className="text-sm text-gray-600 mb-4">Configure system alerts and notifications</p>
          <button className="w-full bg-yellow-600 text-white py-2 rounded-lg hover:bg-yellow-700 transition-colors text-sm">
            Alert Settings
          </button>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="p-3 bg-purple-100 rounded-lg w-fit mb-4">
            <Settings className="w-6 h-6 text-purple-600" />
          </div>
          <h3 className="font-semibold mb-2">System Config</h3>
          <p className="text-sm text-gray-600 mb-4">System settings and configuration</p>
          <button className="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors text-sm">
            Configuration
          </button>
        </div>
      </div>
    </div>
  );
};