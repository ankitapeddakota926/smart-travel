import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Shield, MapPin, AlertTriangle, MessageCircle, 
  Star, TrendingUp, Clock, Users, Navigation 
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { WeatherCard } from '../common/WeatherCard';
import { SafetyScore } from '../common/SafetyScore';
import { TransportCard } from '../common/TransportCard';

export const TouristDashboard: React.FC = () => {
  const { user } = useAuth();

  const quickActions = [
    { icon: Shield, label: 'Safety Status', path: '/safety-alerts', color: 'green' },
    { icon: MapPin, label: 'Find Safe Zones', path: '/travel-guide', color: 'blue' },
    { icon: AlertTriangle, label: 'Emergency SOS', path: '/emergency-sos', color: 'red' },
    { icon: MessageCircle, label: 'AI Assistant', path: '/support', color: 'purple' }
  ];

  const mockWeatherData = {
    temperature: 22,
    condition: 'sunny' as const,
    humidity: 65,
    windSpeed: 12,
    location: 'New York, NY',
    alerts: ['UV Index High - Use sunscreen']
  };

  const mockTransport = {
    id: '1',
    type: 'taxi' as const,
    name: 'City Taxi',
    eta: '3 min',
    price: '$8-12',
    available: 4,
    rating: 4.8
  };

  const stats = [
    { label: 'Safety Score', value: user?.safetyScore || 85, icon: TrendingUp },
    { label: 'Active Alerts', value: 3, icon: AlertTriangle },
    { label: 'Safe Zones Nearby', value: 12, icon: Shield },
    { label: 'Tourist Reviews', value: 847, icon: Star }
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-8 rounded-2xl shadow-lg">
        <h1 className="text-3xl font-bold mb-2">
          Welcome back, {user?.name || 'Tourist'}!
        </h1>
        <p className="text-blue-100 mb-4">
          Your digital companion for safe and smart travel experiences
        </p>
        <div className="flex items-center space-x-4 text-sm">
          <span className="bg-blue-500 px-3 py-1 rounded-full">
            Digital ID: {user?.digitalId || 'DID-2024-001'}
          </span>
          <span className="bg-green-500 px-3 py-1 rounded-full">
            Status: Active & Safe
          </span>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action, index) => {
          const Icon = action.icon;
          const colorClasses = {
            green: 'bg-green-50 text-green-600 hover:bg-green-100',
            blue: 'bg-blue-50 text-blue-600 hover:bg-blue-100',
            red: 'bg-red-50 text-red-600 hover:bg-red-100',
            purple: 'bg-purple-50 text-purple-600 hover:bg-purple-100'
          };

          return (
            <Link
              key={index}
              to={action.path}
              className={`p-6 rounded-xl border-2 border-transparent hover:border-current transition-all duration-200 transform hover:scale-105 ${
                colorClasses[action.color as keyof typeof colorClasses]
              }`}
            >
              <Icon className="w-8 h-8 mb-3" />
              <h3 className="font-semibold text-sm">{action.label}</h3>
            </Link>
          );
        })}
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-2">
                <Icon className="w-5 h-5 text-gray-500" />
                <span className="text-2xl font-bold text-gray-800">{stat.value}</span>
              </div>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Safety Score */}
        <SafetyScore
          score={user?.safetyScore || 85}
          previousScore={80}
          factors={{
            location: 90,
            timeOfDay: 85,
            crowdLevel: 75,
            weatherCondition: 88
          }}
        />

        {/* Weather Card */}
        <WeatherCard data={mockWeatherData} />

        {/* Transport Options */}
        <TransportCard
          transport={mockTransport}
          onBook={(id) => console.log('Book transport:', id)}
          onViewRoute={(id) => console.log('View route:', id)}
        />
      </div>

      {/* Live Map Preview */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <MapPin className="w-5 h-5 mr-2 text-red-600" />
          Live Location & Safe Zones
        </h2>
        <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
          <div className="text-center">
            <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-600">Interactive map will load here</p>
            <p className="text-sm text-gray-500">Showing safe zones, tourist locations, and real-time alerts</p>
          </div>
        </div>
        <div className="mt-4 flex justify-between items-center">
          <div className="flex space-x-4 text-sm">
            <span className="flex items-center"><div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div> Safe Zones</span>
            <span className="flex items-center"><div className="w-3 h-3 bg-yellow-500 rounded-full mr-1"></div> Caution Areas</span>
            <span className="flex items-center"><div className="w-3 h-3 bg-red-500 rounded-full mr-1"></div> Restricted Zones</span>
          </div>
          <Link 
            to="/travel-guide"
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm flex items-center"
          >
            <Navigation className="w-4 h-4 mr-1" />
            Full Map View
          </Link>
        </div>
      </div>
    </div>
  );
};