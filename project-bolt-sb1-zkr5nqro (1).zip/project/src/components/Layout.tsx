import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { PanicButton } from './PanicButton';
import { Breadcrumb } from './Breadcrumb';
import { PageNavigator } from './common/PageNavigator';
import { AIChat } from './chat/AIChat';

export const Layout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar isOpen={sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} />
      
      <main className="flex-1 lg:ml-0">
        <div className="p-6 lg:p-8 pt-16 lg:pt-8">
          <div className="flex items-center justify-between mb-6">
            <Breadcrumb />
            <PageNavigator />
          </div>
          <Outlet />
        </div>
      </main>

      <PanicButton />
      <AIChat isOpen={chatOpen} onToggle={() => setChatOpen(!chatOpen)} />
    </div>
  );
};