import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { useAuth } from './hooks/useAuth';
import { RoleGuard } from './components/auth/RoleGuard';

// Pages
import { Home } from './pages/Home';
import { DigitalID } from './pages/DigitalID';
import { TravelGuide } from './pages/TravelGuide';
import { SafetyAlerts } from './pages/SafetyAlerts';
import { EmergencySOS } from './pages/EmergencySOS';
import { Transport } from './pages/Transport';
import { Reviews } from './pages/Reviews';
import { Support } from './pages/Support';

// Dashboard Components
import { TouristDashboard } from './components/dashboards/TouristDashboard';
import { AuthorityDashboard } from './components/dashboards/AuthorityDashboard';
import { FamilyDashboard } from './components/dashboards/FamilyDashboard';
import { AdminDashboard } from './components/dashboards/AdminDashboard';

// Simple Login Component
const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const [email, setEmail] = React.useState('demo@safetour.com');
  const [password, setPassword] = React.useState('password');
  const [isLoading, setIsLoading] = React.useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await login(email, password);
    } catch (error) {
      console.error('Login failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-xl">ST</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">SafeTour</h1>
          <p className="text-gray-600">Blockchain-Secured Tourism Platform</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
          >
            {isLoading ? 'Signing In...' : 'Sign In'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Demo credentials pre-filled for testing
          </p>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 animate-pulse">
            <span className="text-white font-bold text-xl">ST</span>
          </div>
          <p className="text-gray-600">Loading SafeTour...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={
            user?.role === 'tourist' ? <TouristDashboard /> :
            user?.role === 'police' ? <AuthorityDashboard /> :
            user?.role === 'family' ? <FamilyDashboard /> :
            user?.role === 'admin' ? <AdminDashboard /> :
            <Home />
          } />
          <Route path="digital-id" element={<DigitalID />} />
          <Route path="travel-guide" element={<TravelGuide />} />
          <Route path="safety-alerts" element={<SafetyAlerts />} />
          <Route path="emergency-sos" element={<EmergencySOS />} />
          <Route path="transport" element={<Transport />} />
          <Route path="reviews" element={<Reviews />} />
          <Route path="support" element={<Support />} />
          
          {/* Role-based Routes */}
          <Route path="authority" element={
            <RoleGuard allowedRoles={['police', 'tourism']}>
              <AuthorityDashboard />
            </RoleGuard>
          } />
          <Route path="family" element={
            <RoleGuard allowedRoles={['family']}>
              <FamilyDashboard />
            </RoleGuard>
          } />
          <Route path="admin" element={
            <RoleGuard allowedRoles={['admin']}>
              <AdminDashboard />
            </RoleGuard>
          } />
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Router>
  );
};

export default App;