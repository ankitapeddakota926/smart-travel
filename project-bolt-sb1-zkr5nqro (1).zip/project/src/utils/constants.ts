export const COLORS = {
  primary: '#3B82F6',
  secondary: '#14B8A6',
  accent: '#F97316',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  panic: '#DC2626'
};

export const SIDEBAR_ITEMS = [
  { id: 'home', label: 'Home', path: '/', icon: 'Home' },
  { id: 'digital-id', label: 'My Digital ID', path: '/digital-id', icon: 'CreditCard' },
  { id: 'travel-guide', label: 'Travel Guide', path: '/travel-guide', icon: 'Map' },
  { id: 'safety', label: 'Safety & Alerts', path: '/safety-alerts', icon: 'Shield' },
  { id: 'emergency', label: 'Emergency SOS', path: '/emergency-sos', icon: 'AlertTriangle' },
  { id: 'transport', label: 'Transport', path: '/transport', icon: 'Car' },
  { id: 'reviews', label: 'Reviews', path: '/reviews', icon: 'Star' },
  { id: 'support', label: 'Support', path: '/support', icon: 'HelpCircle' }
];

export const MOCK_RECOMMENDATIONS = [
  {
    id: '1',
    type: 'attraction' as const,
    name: 'Historic City Center',
    description: 'Beautiful historic architecture and cultural landmarks',
    rating: 4.8,
    image: 'https://images.pexels.com/photos/1388030/pexels-photo-1388030.jpeg',
    location: { lat: 40.7128, lng: -74.0060 }
  },
  {
    id: '2',
    type: 'restaurant' as const,
    name: 'Local Cuisine House',
    description: 'Authentic local dishes with modern twist',
    rating: 4.6,
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg',
    location: { lat: 40.7580, lng: -73.9855 }
  },
  {
    id: '3',
    type: 'hotel' as const,
    name: 'Comfort Inn Downtown',
    description: 'Modern amenities in the heart of the city',
    rating: 4.4,
    image: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg',
    location: { lat: 40.7505, lng: -73.9934 }
  }
];